/* 
 * File:   Hu000318_lab3_7seg.h
 * Author: PC-11
 *
 * Created on June 30, 2020, 1:11 PM
 */

#ifndef HU000318_LAB3_7SEG_H
#define	HU000318_LAB3_7SEG_H

#ifdef	__cplusplus
extern "C" {
#endif

void init7seg();
void showChar7seg(char chr, int right);


#ifdef	__cplusplus
}
#endif

#endif	/* HU000318_LAB3_7SEG_H */

