/*
 * File:   Hu000318_lab3a_asmLib_v001.c
 * Author: PC-11
 *
 * Created on June 23, 2020, 3:39 PM
 */

#include "xc.h"
#include "Hu000318_lab3_7seg.h"


void init7seg()
{

        TRISB = TRISB | 0xf003;           // set pin RB< 11:2 > output
        LATB = LATB & 0x03ff;      // set all pin to low 
}



void showChar7seg(char chr, int right)      //show character in screen
{
    LATB = LATB & 0xf3ff;           // set PIN 10,11 low
    LATB = LATB | 0x03fc;           // set PIN 2-9 high
    
    if (right)                
    LATB |= 0x0800;           //set pin10 to high
    else
    LATB |= 0x0400;           //set pin 11 to high


switch (chr)
{
            case '0':
            LATB = LATB & 0xfc0f;
            break;
            case '1':
            LATB = LATB & 0xfe7f;
            break;
            case '2':
            LATB = LATB & 0xfc97;
            break;
            case '3':
            LATB = LATB & 0xfc37;
            break;
            case '4':
            LATB = LATB & 0xfe67;
            break;
            case '5':
            LATB = LATB & 0xfd27;
            break;
            case '6':
            LATB = LATB & 0xfd07;
            break;
            case '7':
            LATB = LATB & 0xfc6f;
            break;
            case '8':
            LATB = LATB & 0xfc07;
            break;
            case '9':
            LATB = LATB & 0xfc27;
            break;
            case 'a':
            LATB = LATB & 0xfc47;
            break;
            case 'b':
            LATB = LATB & 0xff07;
            break;
            case 'c':
            LATB = LATB & 0xfd8f;
            break;
            case 'd':
            LATB = LATB & 0xfe17;
            break;
            case 'e':
            LATB = LATB & 0xfd87;
            break;
            case 'f':
            LATB = LATB & 0xfdc7;
            break;
            case 'x':
            break;
            
}

}


