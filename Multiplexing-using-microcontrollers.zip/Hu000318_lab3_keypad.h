/* 
 * File:   Hu000318_lab3_keypad.h
 * Author: PC-11
 *
 * Created on June 30, 2020, 1:13 PM
 */

#ifndef HU000318_LAB3_KEYPAD_H
#define	HU000318_LAB3_KEYPAD_H

#ifdef	__cplusplus
extern "C" {
#endif

void initkeypad();
char ReadKeyPadRaw();


#ifdef	__cplusplus
}
#endif

#endif	/* HU000318_LAB3_KEYPAD_H */

