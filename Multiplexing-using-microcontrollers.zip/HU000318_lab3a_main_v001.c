/*
 * File:   newmainXC16.c
 * Author: PC-11
 *
 * Created on June 23, 2020, 3:39 PM
 */



#include "xc.h"
#include "stdint.h"
#include "Hu000318_lab3a_asmLib_v001.h"
#include "Hu000318_lab3_keypad.h"
#include "Hu000318_lab3_7seg.h"

#pragma config POSCMOD = NONE      // Primary Oscillator Select (Primary oscillator disabled)
#pragma config I2C1SEL = PRI       // I2C1 Pin Location Select (Use default SCL1/SDA1 pins)
#pragma config IOL1WAY = OFF       // IOLOCK Protection (IOLOCK may be changed via unlocking seq)
#pragma config OSCIOFNC = ON       // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as port I/O (RC15))
#pragma config FCKSM = CSECME      // Clock Switching and Monitor (Clock switching is enabled,
                                       // Fail-Safe Clock Monitor is enabled)
#pragma config FNOSC = FRCPLL      // Oscillator Select (Fast RC Oscillator with PLL module (FRCPLL))
#pragma config SOSCSEL = SOSC      // Sec Oscillator Select (Default Secondary Oscillator (SOSC))
#pragma config WUTSEL = LEG        // Wake-up timer Select (Legacy Wake-up Timer)
#pragma config IESO = ON           // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)

// CONFIG1
#pragma config WDTPS = PS32768     // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128       // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = ON         // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = OFF        // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config ICS = PGx1          // Comm Channel Select (Emulator EMUC1/EMUD1 pins are shared with PGC1/PGD1)
#pragma config GWRP = OFF          // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF           // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF        // JTAG Port Enable (JTAG port is disabled)

char chr;
int new_state;
 char newchr=0, leftchr=0, rightchr=0;

void setup()
{
CLKDIVbits.RCDIV = 0;  //Set RCDIV=1:1 (default 2:1) 32MHz or FCY/2=16M

AD1PCFG = 0xffff;            //sets all pins to digital I/O
TRISA = 0xffff;  //set port A to inputs,
TRISB = 0b0000000000000011;  //and port B to outputs
LATA = 0xffff;               //Set all of port A to HIGH
LATB = 0xffff;               //and all of port B to HIGH

}

void wait_n_ms(int delay){
    int i= delay;
    for(i;i>0;i--){
       
        wait_1ms();
    }
}





void orserTest7seg() {
    showChar7seg('0', 0);
    wait_n_ms(1000);
    showChar7seg('1', 1);
    wait_n_ms(1000);
    showChar7seg('2', 0);
    wait_n_ms(1000);
    showChar7seg('3', 1);
    wait_n_ms(1000);
    showChar7seg('4', 0);
    wait_n_ms(1000);
    showChar7seg('5', 1);
    wait_n_ms(1000);
    showChar7seg('6', 0);
    wait_n_ms(1000);
    showChar7seg('7', 1);
    wait_n_ms(1000);
    showChar7seg('8', 0);
    wait_n_ms(1000);
    showChar7seg('9', 1);
    wait_n_ms(1000);
    showChar7seg('a', 0);
    wait_n_ms(1000);
    showChar7seg('b', 1);
    wait_n_ms(1000);
    showChar7seg('c', 0);
    wait_n_ms(1000);
    showChar7seg('d', 1);
    wait_n_ms(1000);
    showChar7seg('e', 0);
    wait_n_ms(1000);
    showChar7seg('f', 1);
    wait_n_ms(1000);


}       //test output function

void display(){



 

    newchr = ReadKeyPadRaw();
    

    if(newchr != rightchr){
        if (newchr == 'x'){
            new_state = 1;
        }else {
            leftchr = rightchr;
            rightchr = newchr;
            new_state = 0;
        }
    }else{
        if(new_state == 1){
            leftchr = rightchr;
            new_state = 0;
        }
    }
    
        showChar7seg( rightchr, 1);
    wait_n_ms(10);
        showChar7seg( leftchr, 0);    
        wait_n_ms(10);
}

int main(void)
{
  
   
setup();
init7seg(); 
initkeypad();

 

while (1) {
   
    display();
//    chr = ReadKeyPadRaw();
//    showChar7seg( chr, 0);  
    
    
}
   
   
   
    return 0;
}

