/*
 * File:   Hu000318_lab3a_asmLib_v001.c
 * Author: PC-11
 *
 * Created on June 23, 2020, 3:39 PM
 */

#include "xc.h"
#include "Hu000318_lab3_keypad.h"
#include "Hu000318_lab3a_asmLib_v001.h"


void initkeypad(){
            //sets all pins to digital I/O
   
    TRISA|= 0x000f;     //set RA[0:3]to input
    TRISB&= 0x0fff;     //set RB[15:12]to output
                        //enable internal pull-up resistor for RA[0:3]
    CNPU1 = 0x000c;     //CN2,CN3
    CNPU2 = 0x6000;     //CN29,CN30  

}       //set up I/O, pull-up resistors




char ReadKeyPadRaw(){

    char chr;
    int col;
    unsigned int executerow[4] = {0,1,2,3};
    unsigned int ain;
    executerow[0] = 0xefff;         //RB12 = row 0
    executerow[1] = 0xdfff;         //RB13 = row 0
    executerow[2] = 0xbfff;         //RB14 = row 0
    executerow[3] = 0x7fff;         //RB15 = row 0
    int n = -1;  
    

    
    for (n=0; n<4; n++){
        LATB |= 0xf000;             // set RB12-RB15 to high
        LATB &= executerow[n];     // set row n to low  // 1) deb 2) read&mask--> Store in another var

        wait_1ms();
        
        ain = PORTA & 0x000f;
            
         if(ain == 0x000e){
                col = 0;            //AN0 = low(PORTA == 0x000d)
                break;
            }
        else  if(ain == 0x000d){
                col = 1;           //AN1 = low
                break;
            }        
        else if(ain == 0x000b){
                col = 2;           //AN2 = low
                break;
            } 
        else if(ain == 0x0007){
                col = 3;           //AN3 = low
                break;
            } 
        

     }
    
    if (n == 0){
        switch (col){
            case 0:
                chr = 'a';
                break;
            case 1:
                chr = '3';
                break;            
            case 2:
                chr = '2';
                break;        
            case 3:
                chr = '1';
                break;        
         }
    }
    
    else if (n == 1){
        switch (col){
            case 0:
                chr = 'b';
                break;
            case 1:
                chr = '6';
                break;            
            case 2:
                chr = '5';
                break;        
            case 3:
                chr = '4';
                break;        
         }
    }
    
    else if (n == 2){
        switch (col){
            case 0:
                chr = 'c';
                break;
            case 1:
                chr = '9';
                break;            
            case 2:
                chr = '8';
                break;        
            case 3:
                chr = '7';
                break;        
         }
    }
    
    else if (n == 3){
        switch (col){
            case 0:
                chr = 'd';
                break;
            case 1:
                chr = 'e';      // #
                break;            
            case 2:
                chr = '0';
                break;        
            case 3:
                chr = 'f';      //*
                break;        
         }
    }
    
    else {
        chr = 'x';
    }
    
    return chr;
}
